import matplotlib.pyplot as plt
import csv

def crear_grafico_ventas_por_region(archivo_csv):
    # Diccionario para almacenar los datos por columnas
    Datos_por_columna = {}

    # Leer datos del archivo CSV
    with open(archivo_csv, 'r', encoding='utf-8') as archivo_csv:
        lector = csv.DictReader(archivo_csv)
        for fila in lector:
            for columna, valor in fila.items():
                # Si es la primera vez que se encuentra la columna, crear una lista vacia para almacenar los valores
                if columna not in Datos_por_columna:
                   Datos_por_columna[columna] = []
                # Agregar el valor a la lista correspondiente
                Datos_por_columna[columna].append(valor)

    # Calcular las ventas totales por region
    ventas_por_region = {}
    for i, region in enumerate(Datos_por_columna['Region']):
        if region not in ventas_por_region:
            ventas_por_region[region] = 0
        ventas_por_region[region] += float(Datos_por_columna['Monto'][i])

    # Crear el grafico de torta
    plt.pie(ventas_por_region.values(), labels=ventas_por_region.keys(), autopct=lambda p: '{:.0f}'.format(p * sum(ventas_por_region.values()) / 100))

    # Personalizar el grafico
    plt.title('Ventas totales por region')  # Titulo del grafico

    # Mostrar el grafico
    plt.show()  # Muestra el grafico generado

# Llamada a la funcion con el nombre del archivo CSV como argumento
crear_grafico_ventas_por_region('Datos.csv')



