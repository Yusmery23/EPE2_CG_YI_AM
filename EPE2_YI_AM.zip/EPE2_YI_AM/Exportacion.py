import csv
from datetime import datetime

def ingresar_vendedor():
    print("Seleccione un vendedor:")
    vendedores = ["Vendedor1", "Vendedor2", "Vendedor3", "Vendedor4"]
    for i, vendedor in enumerate(vendedores, start=1):
        print(f"{i}. {vendedor}")
    seleccion = int(input("Ingrese el número correspondiente al vendedor: "))
    return vendedores[seleccion - 1]

def ingresar_Datos():
    region = input("Ingrese la region: ")
    anio = input("Ingrese el anio: ")
    categoria = input("Ingrese la categoria de producto: ")
    vendedor = input("Ingrese el nombre del vendedor: ")
    monto = float(input("Ingrese el monto: "))
    #obtenemos el año actual 
    anio = datetime.today().strftime('%Y')
    return [region, categoria, vendedor, monto, anio]

def guardar_datos(Datos):
    with open('Datos.csv', 'a', newline='') as archivo_csv:
        escritor = csv.writer(archivo_csv)
        escritor.writerow(Datos)

def generar_grafico():
    pass

def main():
    #obtenemos el vendedor seleccionado
    vendedor = ingresar_vendedor()

    cabecera = ["Region", "Categoria", "Vendedor", "Monto", "Anio"]
    # Verificar si el archivo CSV ya existe para no escribir la cabecera nuevamente
    try:
        with open('Datos.csv', 'r') as archivo_csv:
            lector = csv.reader(archivo_csv)
            if not any(lector):
                with open('Datos.csv', 'a', newline='') as archivo_csv:
                    escritor = csv.writer(archivo_csv)
                    escritor.writerow(cabecera)
    except FileNotFoundError:
        with open('Datos.csv', 'a', newline='') as archivo_csv:
            escritor = csv.writer(archivo_csv)
            escritor.writerow(cabecera)

    datos = ingresar_Datos()
    guardar_datos(datos)

    generar_grafico()

if __name__ == "__main__":
    main()
